LONPOS PWA für iPhone

INSTALLATION:
1. Lade den Ordner auf einen HTTPS-Webhost hoch (z.B. GitHub Pages, Netlify oder Cloudflare Pages).
2. Öffne die Adresse in Safari auf dem iPhone.
3. Teilen -> Zum Home-Bildschirm -> Hinzufügen.
4. Danach startet LONPOS wie eine App.

OFFLINE:
Der Service Worker speichert die App-Dateien nach dem ersten Aufruf für Offline-Nutzung.

WICHTIG:
Für eine echte App-Store-App brauchst du weiterhin einen iOS-Build (z.B. Xcode/Mac oder einen Cloud-Build-Dienst).
