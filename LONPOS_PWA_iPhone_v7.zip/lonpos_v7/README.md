LONPOS PWA – Version 6

5x11 board, 12 photographed pieces, direct touch movement, rotate/mirror controls, deterministic guaranteed solution, animated loading screen.
